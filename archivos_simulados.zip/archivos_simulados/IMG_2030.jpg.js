⚠ Script JS oculto bajo nombre de imagen.
